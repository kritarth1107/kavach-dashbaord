module.exports=[34667,(e,o,d)=>{}];

//# sourceMappingURL=0ivl_api_families_%5BfamilyId%5D_recipients_%5BrecipientUserId%5D_labs_route_actions_0t36mq6.js.map