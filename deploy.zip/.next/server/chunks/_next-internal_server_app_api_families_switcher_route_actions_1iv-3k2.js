module.exports=[3366,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_families_switcher_route_actions_1iv-3k2.js.map