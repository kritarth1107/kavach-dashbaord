module.exports=[39970,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_integrations_zepto_callback_route_actions_1dnk18i.js.map