module.exports=[74420,(e,o,d)=>{}];

//# sourceMappingURL=1jng_app_api_families_%5BfamilyId%5D_orders_%5BorderId%5D_reject_route_actions_18llrtr.js.map