module.exports=[96820,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_families_invitations_accept_route_actions_1u9rubm.js.map