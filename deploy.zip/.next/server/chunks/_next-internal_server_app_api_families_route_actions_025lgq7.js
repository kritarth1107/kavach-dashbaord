module.exports=[25174,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_families_route_actions_025lgq7.js.map