module.exports=[86922,(e,o,d)=>{}];

//# sourceMappingURL=1jng_app_api_families_%5BfamilyId%5D_integrations_zepto_status_route_actions_055ck7z.js.map