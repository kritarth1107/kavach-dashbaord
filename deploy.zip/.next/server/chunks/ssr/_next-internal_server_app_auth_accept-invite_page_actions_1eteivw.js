module.exports=[62149,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_auth_accept-invite_page_actions_1eteivw.js.map