module.exports=[40220,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_auth_pending-invite_page_actions_0-emtv0.js.map