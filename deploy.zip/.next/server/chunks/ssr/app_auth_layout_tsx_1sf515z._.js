module.exports=[10019,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)("div",{className:"h-full min-h-screen bg-[#fafafa]",children:a})}])},85637,function(a){a.n(a.i(10019))}];

//# sourceMappingURL=app_auth_layout_tsx_1sf515z._.js.map