module.exports=[9620,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_family_page_actions_0gwmynl.js.map