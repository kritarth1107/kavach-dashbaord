module.exports=[52650,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_alerts_page_actions_11sgm00.js.map