module.exports=[60481,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_record_page_actions_11dw7o6.js.map