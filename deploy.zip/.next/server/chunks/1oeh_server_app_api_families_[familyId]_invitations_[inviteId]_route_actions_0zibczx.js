module.exports=[3392,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_families_%5BfamilyId%5D_invitations_%5BinviteId%5D_route_actions_0zibczx.js.map