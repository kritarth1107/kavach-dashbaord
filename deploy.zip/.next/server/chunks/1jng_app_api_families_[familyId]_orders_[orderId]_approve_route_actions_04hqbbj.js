module.exports=[87684,(e,o,d)=>{}];

//# sourceMappingURL=1jng_app_api_families_%5BfamilyId%5D_orders_%5BorderId%5D_approve_route_actions_04hqbbj.js.map