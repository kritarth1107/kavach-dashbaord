module.exports=[1855,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_families_%5BfamilyId%5D_orders_history_route_actions_12st_zh.js.map