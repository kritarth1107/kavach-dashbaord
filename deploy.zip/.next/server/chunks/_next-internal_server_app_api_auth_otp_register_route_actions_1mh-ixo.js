module.exports=[36556,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_otp_register_route_actions_1mh-ixo.js.map