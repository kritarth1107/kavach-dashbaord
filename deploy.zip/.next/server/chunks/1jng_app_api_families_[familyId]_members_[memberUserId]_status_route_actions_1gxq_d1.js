module.exports=[12664,(e,o,d)=>{}];

//# sourceMappingURL=1jng_app_api_families_%5BfamilyId%5D_members_%5BmemberUserId%5D_status_route_actions_1gxq_d1.js.map