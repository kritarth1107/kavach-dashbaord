module.exports=[13307,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_families_active_route_actions_189ssoi.js.map