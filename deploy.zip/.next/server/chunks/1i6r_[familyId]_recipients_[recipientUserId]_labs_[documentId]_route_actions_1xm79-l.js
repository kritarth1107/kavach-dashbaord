module.exports=[15791,(e,o,d)=>{}];

//# sourceMappingURL=1i6r_%5BfamilyId%5D_recipients_%5BrecipientUserId%5D_labs_%5BdocumentId%5D_route_actions_1xm79-l.js.map