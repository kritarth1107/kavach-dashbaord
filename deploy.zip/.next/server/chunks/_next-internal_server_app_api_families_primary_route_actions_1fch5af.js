module.exports=[71237,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_families_primary_route_actions_1fch5af.js.map