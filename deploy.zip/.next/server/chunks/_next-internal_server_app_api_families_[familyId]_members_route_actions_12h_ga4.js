module.exports=[78457,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_families_%5BfamilyId%5D_members_route_actions_12h_ga4.js.map