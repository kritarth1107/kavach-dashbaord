var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/users/me/sessions/route.js")
R.c("server/chunks/[root-of-the-server]__0fmfcw1._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_users_me_sessions_route_actions_1blx8tc.js")
R.m(95301)
module.exports=R.m(95301).exports
