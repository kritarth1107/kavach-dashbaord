var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/users/me/sessions/[sessionId]/route.js")
R.c("server/chunks/[root-of-the-server]__1t6ouph._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_users_me_sessions_[sessionId]_route_actions_027i502.js")
R.m(26875)
module.exports=R.m(26875).exports
