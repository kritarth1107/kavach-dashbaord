var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/users/me/sessions/revoke-others/route.js")
R.c("server/chunks/[root-of-the-server]__0nxwrlv._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_users_me_sessions_revoke-others_route_actions_0sgotdf.js")
R.m(69903)
module.exports=R.m(69903).exports
