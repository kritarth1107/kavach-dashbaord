var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/users/me/route.js")
R.c("server/chunks/[root-of-the-server]__03vb6c_._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_users_me_route_actions_06v51f-.js")
R.m(57190)
module.exports=R.m(57190).exports
