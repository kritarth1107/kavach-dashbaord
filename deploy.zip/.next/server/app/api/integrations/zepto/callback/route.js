var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/integrations/zepto/callback/route.js")
R.c("server/chunks/[root-of-the-server]__1wtovh2._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_integrations_zepto_callback_route_actions_1dnk18i.js")
R.m(70588)
module.exports=R.m(70588).exports
