var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/otp/send/route.js")
R.c("server/chunks/[root-of-the-server]__18xn6t0._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_otp_send_route_actions_0ivwinv.js")
R.m(72445)
module.exports=R.m(72445).exports
