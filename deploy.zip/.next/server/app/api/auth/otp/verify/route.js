var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/otp/verify/route.js")
R.c("server/chunks/[root-of-the-server]__0r32gcw._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_otp_verify_route_actions_1rku5r1.js")
R.m(31878)
module.exports=R.m(31878).exports
