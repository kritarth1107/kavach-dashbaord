var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/otp/register/route.js")
R.c("server/chunks/[root-of-the-server]__0_42gqi._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_otp_register_route_actions_1mh-ixo.js")
R.m(92807)
module.exports=R.m(92807).exports
