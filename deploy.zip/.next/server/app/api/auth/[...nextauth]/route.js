var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__0-5k-lj._.js")
R.c("server/chunks/node_modules_0w63wvw._.js")
R.c("server/chunks/_1ccu7b9._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_[___nextauth]_route_actions_08nexdk.js")
R.m(59061)
module.exports=R.m(59061).exports
