var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/establish-session/route.js")
R.c("server/chunks/[root-of-the-server]__1yxtqlb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/node_modules_1hlmxn2._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_establish-session_route_actions_0i4j8i0.js")
R.m(53354)
module.exports=R.m(53354).exports
