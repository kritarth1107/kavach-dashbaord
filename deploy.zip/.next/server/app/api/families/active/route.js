var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/active/route.js")
R.c("server/chunks/[root-of-the-server]__1e1jysp._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_families_active_route_actions_189ssoi.js")
R.m(81286)
module.exports=R.m(81286).exports
