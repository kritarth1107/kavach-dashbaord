var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/families/route.js")
R.c("server/chunks/[root-of-the-server]__0u7m8o0._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_families_route_actions_025lgq7.js")
R.m(64562)
module.exports=R.m(64562).exports
