var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/invitations/respond/reject/route.js")
R.c("server/chunks/[root-of-the-server]__1wx23_p._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_families_invitations_respond_reject_route_actions_1pkczgd.js")
R.m(19162)
module.exports=R.m(19162).exports
