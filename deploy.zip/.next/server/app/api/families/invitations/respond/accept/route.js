var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/invitations/respond/accept/route.js")
R.c("server/chunks/[root-of-the-server]__1xkmg_s._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_families_invitations_respond_accept_route_actions_1xsd6ar.js")
R.m(76684)
module.exports=R.m(76684).exports
