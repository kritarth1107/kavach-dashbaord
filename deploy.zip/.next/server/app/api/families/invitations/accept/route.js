var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/invitations/accept/route.js")
R.c("server/chunks/[root-of-the-server]__0rk4gzi._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_families_invitations_accept_route_actions_1u9rubm.js")
R.m(2293)
module.exports=R.m(2293).exports
