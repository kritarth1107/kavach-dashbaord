var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/primary/route.js")
R.c("server/chunks/[root-of-the-server]__0ohxn1o._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_families_primary_route_actions_1fch5af.js")
R.m(4290)
module.exports=R.m(4290).exports
