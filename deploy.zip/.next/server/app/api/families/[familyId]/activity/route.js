var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/activity/route.js")
R.c("server/chunks/[root-of-the-server]__1aeh40n._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_families_[familyId]_activity_route_actions_1vv6k9x.js")
R.m(12420)
module.exports=R.m(12420).exports
