var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/integrations/zepto/route.js")
R.c("server/chunks/[root-of-the-server]__1hamse0._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_families_[familyId]_integrations_zepto_route_actions_1cfega2.js")
R.m(62320)
module.exports=R.m(62320).exports
