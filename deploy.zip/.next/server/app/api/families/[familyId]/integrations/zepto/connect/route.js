var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/integrations/zepto/connect/route.js")
R.c("server/chunks/[root-of-the-server]__15tnd5-._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1jng_app_api_families_[familyId]_integrations_zepto_connect_route_actions_1o-fxdd.js")
R.m(22665)
module.exports=R.m(22665).exports
