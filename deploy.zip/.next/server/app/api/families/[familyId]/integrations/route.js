var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/integrations/route.js")
R.c("server/chunks/[root-of-the-server]__10vm_f4._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_families_[familyId]_integrations_route_actions_0hx2-ts.js")
R.m(37782)
module.exports=R.m(37782).exports
