var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/integrations/zepto/status/route.js")
R.c("server/chunks/[root-of-the-server]__12jd7c_._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1jng_app_api_families_[familyId]_integrations_zepto_status_route_actions_055ck7z.js")
R.m(74489)
module.exports=R.m(74489).exports
