var R=require("../../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/subjects/[subjectUserId]/care-record/metrics/route.js")
R.c("server/chunks/[root-of-the-server]__1x60jse._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1i6r_[familyId]_subjects_[subjectUserId]_care-record_metrics_route_actions_0cmmyjw.js")
R.m(66664)
module.exports=R.m(66664).exports
