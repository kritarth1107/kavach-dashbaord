var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/subjects/[subjectUserId]/care-brief/route.js")
R.c("server/chunks/[root-of-the-server]__0d3oinf._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/07_e_families_[familyId]_subjects_[subjectUserId]_care-brief_route_actions_0v8zms2.js")
R.m(66012)
module.exports=R.m(66012).exports
