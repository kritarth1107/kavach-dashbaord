var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/recipients/[recipientUserId]/briefing/route.js")
R.c("server/chunks/[root-of-the-server]__1rhvhfo._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/07_e_families_[familyId]_recipients_[recipientUserId]_briefing_route_actions_0vhobbm.js")
R.m(99556)
module.exports=R.m(99556).exports
