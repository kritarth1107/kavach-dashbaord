var R=require("../../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/recipients/[recipientUserId]/saheli/check-in/route.js")
R.c("server/chunks/[root-of-the-server]__0d6ntql._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1i6r_[familyId]_recipients_[recipientUserId]_saheli_check-in_route_actions_1mgm6s4.js")
R.m(46392)
module.exports=R.m(46392).exports
