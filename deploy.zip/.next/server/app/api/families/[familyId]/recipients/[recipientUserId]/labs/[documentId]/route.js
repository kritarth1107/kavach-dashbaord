var R=require("../../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/recipients/[recipientUserId]/labs/[documentId]/route.js")
R.c("server/chunks/[root-of-the-server]__0lvrbr7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1i6r_[familyId]_recipients_[recipientUserId]_labs_[documentId]_route_actions_1xm79-l.js")
R.m(56906)
module.exports=R.m(56906).exports
