var R=require("../../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/recipients/[recipientUserId]/labs/upload/route.js")
R.c("server/chunks/[root-of-the-server]__1yce4n0._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1i6r_[familyId]_recipients_[recipientUserId]_labs_upload_route_actions_00hnbsv.js")
R.m(70749)
module.exports=R.m(70749).exports
