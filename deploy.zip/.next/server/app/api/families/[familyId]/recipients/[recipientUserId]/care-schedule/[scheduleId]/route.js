var R=require("../../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/recipients/[recipientUserId]/care-schedule/[scheduleId]/route.js")
R.c("server/chunks/[root-of-the-server]__0dcob6v._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/0_ps_recipients_[recipientUserId]_care-schedule_[scheduleId]_route_actions_0thsfis.js")
R.m(14713)
module.exports=R.m(14713).exports
