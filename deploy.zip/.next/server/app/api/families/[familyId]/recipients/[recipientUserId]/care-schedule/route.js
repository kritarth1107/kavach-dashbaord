var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/recipients/[recipientUserId]/care-schedule/route.js")
R.c("server/chunks/[root-of-the-server]__17nx9z8._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1i6r_[familyId]_recipients_[recipientUserId]_care-schedule_route_actions_1_is827.js")
R.m(17744)
module.exports=R.m(17744).exports
