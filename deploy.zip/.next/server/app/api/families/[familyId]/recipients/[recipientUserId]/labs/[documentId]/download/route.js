var R=require("../../../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/recipients/[recipientUserId]/labs/[documentId]/download/route.js")
R.c("server/chunks/[root-of-the-server]__0tinxb7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/0_ps_recipients_[recipientUserId]_labs_[documentId]_download_route_actions_1w3at7e.js")
R.m(9917)
module.exports=R.m(9917).exports
