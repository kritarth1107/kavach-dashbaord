var R=require("../../../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/recipients/[recipientUserId]/saheli/caregiver/chat/route.js")
R.c("server/chunks/[root-of-the-server]__1qabewb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/0_ps_recipients_[recipientUserId]_saheli_caregiver_chat_route_actions_036m8gl.js")
R.m(61393)
module.exports=R.m(61393).exports
