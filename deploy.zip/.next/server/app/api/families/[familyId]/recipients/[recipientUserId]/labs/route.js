var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/recipients/[recipientUserId]/labs/route.js")
R.c("server/chunks/[root-of-the-server]__0ozt47n._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/0ivl_api_families_[familyId]_recipients_[recipientUserId]_labs_route_actions_0t36mq6.js")
R.m(37824)
module.exports=R.m(37824).exports
