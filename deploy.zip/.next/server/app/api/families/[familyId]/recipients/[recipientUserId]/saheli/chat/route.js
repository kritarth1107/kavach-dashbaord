var R=require("../../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/recipients/[recipientUserId]/saheli/chat/route.js")
R.c("server/chunks/[root-of-the-server]__1vhgy5a._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1i6r_[familyId]_recipients_[recipientUserId]_saheli_chat_route_actions_017-ehs.js")
R.m(59091)
module.exports=R.m(59091).exports
