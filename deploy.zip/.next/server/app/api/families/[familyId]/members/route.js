var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/members/route.js")
R.c("server/chunks/[root-of-the-server]__015prwk._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_families_[familyId]_members_route_actions_12h_ga4.js")
R.m(3790)
module.exports=R.m(3790).exports
