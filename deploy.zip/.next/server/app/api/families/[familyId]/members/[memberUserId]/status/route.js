var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/members/[memberUserId]/status/route.js")
R.c("server/chunks/[root-of-the-server]__1uhc8w_._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1jng_app_api_families_[familyId]_members_[memberUserId]_status_route_actions_1gxq_d1.js")
R.m(49269)
module.exports=R.m(49269).exports
