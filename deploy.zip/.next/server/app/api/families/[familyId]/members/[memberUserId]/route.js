var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/members/[memberUserId]/route.js")
R.c("server/chunks/[root-of-the-server]__1swpnlq._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_families_[familyId]_members_[memberUserId]_route_actions_0-3rlrk.js")
R.m(61139)
module.exports=R.m(61139).exports
