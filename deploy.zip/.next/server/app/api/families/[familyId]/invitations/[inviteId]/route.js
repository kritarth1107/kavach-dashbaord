var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/invitations/[inviteId]/route.js")
R.c("server/chunks/[root-of-the-server]__1i312hc._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_families_[familyId]_invitations_[inviteId]_route_actions_0zibczx.js")
R.m(68632)
module.exports=R.m(68632).exports
