var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/orders/[orderId]/approve/route.js")
R.c("server/chunks/[root-of-the-server]__0bs0mzt._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1jng_app_api_families_[familyId]_orders_[orderId]_approve_route_actions_04hqbbj.js")
R.m(80234)
module.exports=R.m(80234).exports
