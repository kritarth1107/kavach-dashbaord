var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/orders/history/route.js")
R.c("server/chunks/[root-of-the-server]__12elgst._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_families_[familyId]_orders_history_route_actions_12st_zh.js")
R.m(25233)
module.exports=R.m(25233).exports
