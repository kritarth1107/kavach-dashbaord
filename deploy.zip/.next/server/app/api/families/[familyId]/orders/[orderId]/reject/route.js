var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/orders/[orderId]/reject/route.js")
R.c("server/chunks/[root-of-the-server]__1ffe_w9._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1jng_app_api_families_[familyId]_orders_[orderId]_reject_route_actions_18llrtr.js")
R.m(4922)
module.exports=R.m(4922).exports
