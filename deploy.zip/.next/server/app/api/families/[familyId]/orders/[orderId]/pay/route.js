var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/orders/[orderId]/pay/route.js")
R.c("server/chunks/[root-of-the-server]__1u9fr02._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_families_[familyId]_orders_[orderId]_pay_route_actions_0n96bax.js")
R.m(42934)
module.exports=R.m(42934).exports
