var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/approvals/pending/route.js")
R.c("server/chunks/[root-of-the-server]__0teo5t5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_families_[familyId]_approvals_pending_route_actions_1xb0y83.js")
R.m(15504)
module.exports=R.m(15504).exports
