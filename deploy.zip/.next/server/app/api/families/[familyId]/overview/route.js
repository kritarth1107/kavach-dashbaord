var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/[familyId]/overview/route.js")
R.c("server/chunks/[root-of-the-server]__09fhvig._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_families_[familyId]_overview_route_actions_1j9fsbl.js")
R.m(79818)
module.exports=R.m(79818).exports
