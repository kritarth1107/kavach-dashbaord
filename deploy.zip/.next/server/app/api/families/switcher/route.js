var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/families/switcher/route.js")
R.c("server/chunks/[root-of-the-server]__0rlpy8p._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_families_switcher_route_actions_1iv-3k2.js")
R.m(10173)
module.exports=R.m(10173).exports
